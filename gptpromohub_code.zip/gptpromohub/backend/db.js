const { Pool } = require('pg');

/**
 * Configure a PostgreSQL connection pool.
 *
 * The database credentials can be supplied via environment variables. If not
 * provided, sensible defaults are used for local development. The default
 * database is named `promohub` and listens on the standard Postgres port
 * (5432). Adjust these values in a .env file or at deployment time.
 */
const pool = new Pool({
  host: process.env.PGHOST || 'localhost',
  port: process.env.PGPORT ? parseInt(process.env.PGPORT, 10) : 5432,
  user: process.env.PGUSER || 'postgres',
  password: process.env.PGPASSWORD || 'postgres',
  database: process.env.PGDATABASE || 'promohub'
});

module.exports = {
  /**
   * Execute an SQL query using the connection pool. Logs errors and rethrows
   * them so callers can handle them appropriately.
   *
   * @param {string} text The parameterised SQL query
   * @param {Array} [params] Optional list of parameters
   * @returns {Promise<object>} The result object from pg
   */
  query: async (text, params) => {
    const client = await pool.connect();
    try {
      const res = await client.query(text, params);
      return res;
    } catch (err) {
      console.error('Database query error:', err);
      throw err;
    } finally {
      client.release();
    }
  }
};