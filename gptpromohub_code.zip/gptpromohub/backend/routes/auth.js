const express = require('express');
const bcrypt = require('bcrypt');

const db = require('../db');

const router = express.Router();

/**
 * User registration endpoint. Creates a new record in the users table and
 * automatically inserts a corresponding record in the influencer_profiles or
 * brand_profiles table based on the provided `userType`. Passwords are
 * hashed using bcrypt before storage.
 *
 * Expected JSON body:
 * {
 *   "fullName": "string",
 *   "email": "string",
 *   "username": "string",
 *   "password": "string",
 *   "phone": "string",
 *   "countryCode": "string",
 *   "userType": "influencer" | "brand"
 * }
 */
router.post('/signup', async (req, res) => {
  const {
    fullName,
    email,
    username,
    password,
    phone,
    countryCode,
    userType
  } = req.body;

  if (!fullName || !email || !username || !password || !userType) {
    return res.status(400).json({ error: 'Missing required fields' });
  }
  if (!['influencer', 'brand'].includes(userType)) {
    return res.status(400).json({ error: 'Invalid user type' });
  }
  try {
    // Hash the password using bcrypt. A salt round of 10 is a reasonable
    // compromise between security and performance for demonstration purposes.
    const passwordHash = await bcrypt.hash(password, 10);

    // Insert the new user into the users table. The unique constraints on
    // email and username will trigger a Postgres error if duplicates are
    // attempted. We return the created id for further use.
    const insertUserQuery = `
      INSERT INTO users
        (full_name, email, username, password_hash, phone, country_code, user_type, created_at, updated_at)
      VALUES ($1, $2, $3, $4, $5, $6, $7, NOW(), NOW())
      RETURNING id;
    `;
    const result = await db.query(insertUserQuery, [
      fullName,
      email,
      username,
      passwordHash,
      phone,
      countryCode,
      userType
    ]);
    const userId = result.rows[0].id;

    // Create an empty profile row for the user based on their type. This
    // simplifies later update queries because the row will always exist.
    if (userType === 'influencer') {
      await db.query(
        `INSERT INTO influencer_profiles (user_id, created_at, updated_at) VALUES ($1, NOW(), NOW())`,
        [userId]
      );
    } else if (userType === 'brand') {
      await db.query(
        `INSERT INTO brand_profiles (user_id, created_at, updated_at) VALUES ($1, NOW(), NOW())`,
        [userId]
      );
    }

    res.status(201).json({ ok: true, userId });
  } catch (err) {
    console.error('Signup error:', err);
    // Handle unique constraint violation gracefully
    if (err.code === '23505') {
      // 23505 is unique_violation in Postgres
      let detail = 'Duplicate field';
      if (err.detail && err.detail.includes('email')) detail = 'Email already exists';
      if (err.detail && err.detail.includes('username')) detail = 'Username already exists';
      return res.status(409).json({ error: detail });
    }
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * User login endpoint. Validates credentials against the stored password hash.
 * Returns the user id and user type on success. This simplistic implementation
 * does not return a JWT; in a real application you would return a token or
 * establish a session.
 *
 * Expected JSON body:
 * {
 *   "emailOrUsername": "string",
 *   "password": "string"
 * }
 */
router.post('/login', async (req, res) => {
  const { emailOrUsername, password } = req.body;
  if (!emailOrUsername || !password) {
    return res.status(400).json({ error: 'Missing credentials' });
  }
  try {
    // Attempt to find the user by email or username
    const findUserQuery = `
      SELECT id, password_hash, user_type
      FROM users
      WHERE email = $1 OR username = $1
      LIMIT 1;
    `;
    const result = await db.query(findUserQuery, [emailOrUsername]);
    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    const user = result.rows[0];
    const passwordMatch = await bcrypt.compare(password, user.password_hash);
    if (!passwordMatch) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    res.json({ ok: true, userId: user.id, userType: user.user_type });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;