const express = require('express');
const db = require('../db');

const router = express.Router();

/**
 * Update an influencer's location details. Expects the userId to identify
 * which record to update. Location fields correspond to the first step of
 * the influencer onboarding flow.
 *
 * Expected JSON body:
 * {
 *   "userId": number,
 *   "pincode": string,
 *   "city": string,
 *   "state": string,
 *   "locality": string,
 *   "fullAddress": string
 * }
 */
router.post('/location', async (req, res) => {
  const { userId, pincode, city, state, locality, fullAddress } = req.body;
  if (!userId) {
    return res.status(400).json({ error: 'Missing userId' });
  }
  try {
    const updateQuery = `
      UPDATE influencer_profiles
      SET pincode = $2,
          city = $3,
          state = $4,
          locality = $5,
          full_address = $6,
          step_location_done = TRUE,
          updated_at = NOW()
      WHERE user_id = $1;
    `;
    await db.query(updateQuery, [userId, pincode, city, state, locality, fullAddress]);
    res.json({ ok: true });
  } catch (err) {
    console.error('Influencer location update error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * Update an influencer's personal details (gender, DOB, languages, categories).
 * This corresponds to the second onboarding step. Languages and categories
 * should be provided as arrays; they are stored as comma-separated strings.
 *
 * Expected JSON body:
 * {
 *   "userId": number,
 *   "gender": string,
 *   "dateOfBirth": string (ISO date),
 *   "languages": string[],
 *   "mainCategory": string,
 *   "subCategory": string
 * }
 */
router.post('/profile', async (req, res) => {
  const { userId, gender, dateOfBirth, languages, mainCategory, subCategory } = req.body;
  if (!userId) {
    return res.status(400).json({ error: 'Missing userId' });
  }
  try {
    const updateQuery = `
      UPDATE influencer_profiles
      SET gender = $2,
          date_of_birth = $3,
          languages = $4,
          main_category = $5,
          sub_category = $6,
          step_personal_done = TRUE,
          updated_at = NOW()
      WHERE user_id = $1;
    `;
    await db.query(updateQuery, [
      userId,
      gender || null,
      dateOfBirth || null,
      Array.isArray(languages) ? languages.join(',') : languages,
      mainCategory || null,
      subCategory || null
    ]);
    res.json({ ok: true });
  } catch (err) {
    console.error('Influencer profile update error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * Update an influencer's content types. This corresponds to the content
 * selection step. Content types should be provided as an array of strings.
 *
 * Expected JSON body:
 * {
 *   "userId": number,
 *   "contentTypes": string[]
 * }
 */
router.post('/content', async (req, res) => {
  const { userId, contentTypes } = req.body;
  if (!userId) {
    return res.status(400).json({ error: 'Missing userId' });
  }
  try {
    const updateQuery = `
      UPDATE influencer_profiles
      SET content_types = $2,
          updated_at = NOW()
      WHERE user_id = $1;
    `;
    await db.query(updateQuery, [userId, Array.isArray(contentTypes) ? contentTypes.join(',') : contentTypes]);
    res.json({ ok: true });
  } catch (err) {
    console.error('Influencer content update error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * Update an influencer's social media details. Expects multiple optional
 * properties. Only provided fields will be updated; absent fields remain
 * unchanged. Social media step corresponds to the third onboarding step.
 *
 * Expected JSON body:
 * {
 *   "userId": number,
 *   "instagramHandle": string,
 *   "instagramUrl": string,
 *   "instagramFollowers": number,
 *   "youtubeUrl": string,
 *   "youtubeFollowers": number,
 *   "otherSocialLinks": string (JSON or free text)
 * }
 */
router.post('/social', async (req, res) => {
  const {
    userId,
    instagramHandle,
    instagramUrl,
    instagramFollowers,
    youtubeUrl,
    youtubeFollowers,
    otherSocialLinks
  } = req.body;
  if (!userId) {
    return res.status(400).json({ error: 'Missing userId' });
  }
  try {
    // Build dynamic update query using COALESCE to keep existing values if null
    const updateQuery = `
      UPDATE influencer_profiles
      SET instagram_handle = COALESCE($2, instagram_handle),
          instagram_url = COALESCE($3, instagram_url),
          instagram_followers = COALESCE($4, instagram_followers),
          youtube_url = COALESCE($5, youtube_url),
          youtube_followers = COALESCE($6, youtube_followers),
          other_social_links = COALESCE($7, other_social_links),
          step_description_done = step_description_done,
          updated_at = NOW()
      WHERE user_id = $1;
    `;
    await db.query(updateQuery, [
      userId,
      instagramHandle || null,
      instagramUrl || null,
      instagramFollowers || null,
      youtubeUrl || null,
      youtubeFollowers || null,
      otherSocialLinks || null
    ]);
    res.json({ ok: true });
  } catch (err) {
    console.error('Influencer social update error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * Update the influencer's headline/summary. This corresponds to the summary
 * step where creators craft a concise title for their profile.
 *
 * Expected JSON body:
 * {
 *   "userId": number,
 *   "headline": string
 * }
 */
router.post('/summary', async (req, res) => {
  const { userId, headline } = req.body;
  if (!userId) {
    return res.status(400).json({ error: 'Missing userId' });
  }
  try {
    await db.query(
      `UPDATE influencer_profiles SET headline = $2, updated_at = NOW() WHERE user_id = $1`,
      [userId, headline]
    );
    res.json({ ok: true });
  } catch (err) {
    console.error('Influencer summary update error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * Update the influencer's detailed bio/description. This corresponds to the
 * final onboarding step. Marks step_description_done flag as true.
 *
 * Expected JSON body:
 * {
 *   "userId": number,
 *   "bio": string
 * }
 */
router.post('/description', async (req, res) => {
  const { userId, bio } = req.body;
  if (!userId) {
    return res.status(400).json({ error: 'Missing userId' });
  }
  try {
    await db.query(
      `UPDATE influencer_profiles SET bio = $2, step_description_done = TRUE, updated_at = NOW() WHERE user_id = $1`,
      [userId, bio]
    );
    res.json({ ok: true });
  } catch (err) {
    console.error('Influencer description update error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * Retrieve a list of influencers with basic profile information. Joins the
 * users and influencer_profiles tables. Useful for listing pages.
 */
router.get('/', async (req, res) => {
  try {
    const query = `
      SELECT u.username, u.full_name, ip.headline, ip.city, ip.main_category, ip.profile_photo_url
      FROM users u
      JOIN influencer_profiles ip ON ip.user_id = u.id
      WHERE u.user_type = 'influencer'
      ORDER BY u.created_at DESC;
    `;
    const result = await db.query(query);
    res.json({ ok: true, influencers: result.rows });
  } catch (err) {
    console.error('Influencer list error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * Retrieve a single influencer profile by username. Returns detailed
 * information including social links and bio.
 */
router.get('/:username', async (req, res) => {
  const { username } = req.params;
  try {
    const query = `
      SELECT u.id, u.full_name, u.username, ip.*
      FROM users u
      JOIN influencer_profiles ip ON ip.user_id = u.id
      WHERE u.username = $1
      AND u.user_type = 'influencer'
      LIMIT 1;
    `;
    const result = await db.query(query, [username]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Influencer not found' });
    }
    res.json({ ok: true, profile: result.rows[0] });
  } catch (err) {
    console.error('Influencer fetch error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;