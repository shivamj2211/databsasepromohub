const express = require('express');
const db = require('../db');

const router = express.Router();

/**
 * Update brand's goal/intent captured on the "heretodo" page. Records the
 * high-level objective for being on the platform.
 *
 * Expected JSON body:
 * {
 *   "userId": number,
 *   "hereToDo": string
 * }
 */
router.post('/heretodo', async (req, res) => {
  const { userId, hereToDo } = req.body;
  if (!userId) return res.status(400).json({ error: 'Missing userId' });
  try {
    await db.query(
      `UPDATE brand_profiles SET here_to_do = $2, step_heretodo_done = TRUE, updated_at = NOW() WHERE user_id = $1`,
      [userId, hereToDo]
    );
    res.json({ ok: true });
  } catch (err) {
    console.error('Brand heretodo update error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * Update brand budget preferences from the "budget" page. Accepts either a
 * budget level label or min/max values (or both). If min/max are omitted,
 * they remain unchanged.
 *
 * Expected JSON body:
 * {
 *   "userId": number,
 *   "budgetLevel": string,
 *   "budgetMin": number,
 *   "budgetMax": number
 * }
 */
router.post('/budget', async (req, res) => {
  const { userId, budgetLevel, budgetMin, budgetMax } = req.body;
  if (!userId) return res.status(400).json({ error: 'Missing userId' });
  try {
    const updateQuery = `
      UPDATE brand_profiles
      SET budget_level = COALESCE($2, budget_level),
          budget_min_inr = COALESCE($3, budget_min_inr),
          budget_max_inr = COALESCE($4, budget_max_inr),
          step_budget_done = TRUE,
          updated_at = NOW()
      WHERE user_id = $1;
    `;
    await db.query(updateQuery, [userId, budgetLevel || null, budgetMin || null, budgetMax || null]);
    res.json({ ok: true });
  } catch (err) {
    console.error('Brand budget update error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * Update the brand's business type from the "businesstype" page.
 *
 * Expected JSON body:
 * {
 *   "userId": number,
 *   "businessType": string
 * }
 */
router.post('/business', async (req, res) => {
  const { userId, businessType } = req.body;
  if (!userId) return res.status(400).json({ error: 'Missing userId' });
  try {
    await db.query(
      `UPDATE brand_profiles SET business_type = $2, step_business_type_done = TRUE, updated_at = NOW() WHERE user_id = $1`,
      [userId, businessType]
    );
    res.json({ ok: true });
  } catch (err) {
    console.error('Brand business type update error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * Update the brand's influencer needs and platform preferences from the
 * "influncertypeyouneed" page. Preferred platforms and categories should be
 * provided as arrays; they are stored as comma-separated strings.
 *
 * Expected JSON body:
 * {
 *   "userId": number,
 *   "influencerType": string,
 *   "preferredPlatforms": string[],
 *   "preferredCategories": string[]
 * }
 */
router.post('/influencer-need', async (req, res) => {
  const { userId, influencerType, preferredPlatforms, preferredCategories } = req.body;
  if (!userId) return res.status(400).json({ error: 'Missing userId' });
  try {
    const updateQuery = `
      UPDATE brand_profiles
      SET influencer_type = COALESCE($2, influencer_type),
          preferred_platforms = COALESCE($3, preferred_platforms),
          preferred_categories = COALESCE($4, preferred_categories),
          step_influencer_need_done = TRUE,
          updated_at = NOW()
      WHERE user_id = $1;
    `;
    await db.query(updateQuery, [
      userId,
      influencerType || null,
      Array.isArray(preferredPlatforms) ? preferredPlatforms.join(',') : preferredPlatforms,
      Array.isArray(preferredCategories) ? preferredCategories.join(',') : preferredCategories
    ]);
    res.json({ ok: true });
  } catch (err) {
    console.error('Brand influencer need update error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * Retrieve a single brand profile by username. Joins the users and
 * brand_profiles tables.
 */
router.get('/:username', async (req, res) => {
  const { username } = req.params;
  try {
    const query = `
      SELECT u.id, u.full_name, u.username, bp.*
      FROM users u
      JOIN brand_profiles bp ON bp.user_id = u.id
      WHERE u.username = $1
      AND u.user_type = 'brand'
      LIMIT 1;
    `;
    const result = await db.query(query, [username]);
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Brand not found' });
    }
    res.json({ ok: true, profile: result.rows[0] });
  } catch (err) {
    console.error('Brand fetch error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;