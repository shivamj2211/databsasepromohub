-- Database schema for the Promohub application

-- Drop existing enum if it exists (useful during development)
DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM pg_type WHERE typname = 'user_type') THEN
    DROP TYPE user_type;
  END IF;
END $$;

-- Enum to differentiate between influencers and brands. Storing this as a
-- Postgres enum type enforces only permitted values at the database level.
CREATE TYPE user_type AS ENUM ('influencer', 'brand');

-- Users table holds common authentication and identity details. It is the
-- single source of truth for credentials and contact info. Each user is
-- either an influencer or a brand according to the user_type column.
CREATE TABLE IF NOT EXISTS users (
  id             BIGSERIAL PRIMARY KEY,
  full_name      VARCHAR(100) NOT NULL,
  email          VARCHAR(255) NOT NULL UNIQUE,
  username       VARCHAR(50)  NOT NULL UNIQUE,
  password_hash  TEXT         NOT NULL,
  phone          VARCHAR(20),
  country_code   VARCHAR(10),
  user_type      user_type    NOT NULL,
  is_active      BOOLEAN      NOT NULL DEFAULT TRUE,
  created_at     TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- Influencer profiles table contains all onboarding information specific to
-- influencers. Each row corresponds to a single user in the users table.
CREATE TABLE IF NOT EXISTS influencer_profiles (
  user_id             BIGINT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,

  -- Location fields
  pincode             VARCHAR(10),
  city                VARCHAR(100),
  state               VARCHAR(100),
  locality            VARCHAR(150),
  full_address        TEXT,

  -- Personal details
  gender              VARCHAR(20),
  date_of_birth       DATE,
  languages           TEXT,             -- comma-separated list of languages

  -- Category and content preferences
  main_category       VARCHAR(100),
  sub_category        VARCHAR(100),
  content_types       TEXT,             -- comma-separated list of content types

  -- Profile summary and description
  headline            VARCHAR(150),     -- short summary/title
  bio                 TEXT,

  -- Social media details
  instagram_handle    VARCHAR(150),
  instagram_url       TEXT,
  instagram_followers BIGINT,
  youtube_url         TEXT,
  youtube_followers   BIGINT,
  other_social_links  TEXT,

  -- Media assets
  profile_photo_url   TEXT,
  cover_photo_url     TEXT,

  -- Onboarding progress flags
  step_location_done      BOOLEAN NOT NULL DEFAULT FALSE,
  step_personal_done      BOOLEAN NOT NULL DEFAULT FALSE,
  step_description_done   BOOLEAN NOT NULL DEFAULT FALSE,

  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Brand profiles table contains all onboarding information specific to
-- brands. Each row corresponds to a single user in the users table.
CREATE TABLE IF NOT EXISTS brand_profiles (
  user_id                 BIGINT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,

  -- High-level objective from heretodo page
  here_to_do              VARCHAR(100),

  -- Budget information
  budget_level            VARCHAR(50),      -- label like 'Under 1k', '1k-5k', etc.
  budget_min_inr          INTEGER,
  budget_max_inr          INTEGER,

  -- Business details
  business_type           VARCHAR(100),

  -- Influencer preferences
  influencer_type         VARCHAR(100),
  preferred_platforms     TEXT,             -- comma-separated platforms
  preferred_categories    TEXT,             -- comma-separated categories

  -- Brand profile information
  brand_name              VARCHAR(150),
  website_url             TEXT,
  logo_url                TEXT,
  about                   TEXT,
  city                    VARCHAR(100),
  state                   VARCHAR(100),
  pincode                 VARCHAR(10),
  full_address            TEXT,

  -- Onboarding progress flags
  step_heretodo_done          BOOLEAN NOT NULL DEFAULT FALSE,
  step_budget_done            BOOLEAN NOT NULL DEFAULT FALSE,
  step_business_type_done     BOOLEAN NOT NULL DEFAULT FALSE,
  step_influencer_need_done   BOOLEAN NOT NULL DEFAULT FALSE,

  created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Additional indexing to speed up queries on usernames, cities or categories
CREATE INDEX IF NOT EXISTS idx_users_user_type ON users(user_type);
CREATE INDEX IF NOT EXISTS idx_influencer_city ON influencer_profiles(city);