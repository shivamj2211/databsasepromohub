/**
 * @type {import('next').NextConfig}
 */
const nextConfig = {
  reactStrictMode: true,
  // Enable CORS by configuring rewrites: proxy API requests starting with
  // /api/ to the backend server running on port 4000 during development.
  async rewrites() {
    return [
      {
        source: '/api/:path*',
        destination: 'http://localhost:4000/api/:path*'
      }
    ];
  }
};

module.exports = nextConfig;