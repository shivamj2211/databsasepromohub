'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function SignupPage() {
  const router = useRouter();
  const [form, setForm] = useState({
    fullName: '',
    email: '',
    username: '',
    password: '',
    phone: '',
    countryCode: '+91',
    userType: 'influencer'
  });
  const [error, setError] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const res = await fetch('/api/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form)
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Signup failed');
      }
      // Save the userId and userType to sessionStorage for subsequent steps
      if (typeof window !== 'undefined') {
        sessionStorage.setItem('userId', data.userId);
        sessionStorage.setItem('userType', form.userType);
      }
      // Redirect based on user type
      if (form.userType === 'influencer') {
        router.push('/influencer/location');
      } else {
        router.push('/brand/heretodo');
      }
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div>
      <h1>Sign Up</h1>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
        <input name="fullName" placeholder="Full name" value={form.fullName} onChange={handleChange} required />
        <input name="email" type="email" placeholder="Email" value={form.email} onChange={handleChange} required />
        <input name="username" placeholder="Username" value={form.username} onChange={handleChange} required />
        <input name="password" type="password" placeholder="Password" value={form.password} onChange={handleChange} required />
        <input name="phone" placeholder="Phone" value={form.phone} onChange={handleChange} />
        <input name="countryCode" placeholder="Country code" value={form.countryCode} onChange={handleChange} />
        <div>
          <label>
            <input
              type="radio"
              name="userType"
              value="influencer"
              checked={form.userType === 'influencer'}
              onChange={handleChange}
            />
            Influencer
          </label>
          <label style={{ marginLeft: '1rem' }}>
            <input
              type="radio"
              name="userType"
              value="brand"
              checked={form.userType === 'brand'}
              onChange={handleChange}
            />
            Brand
          </label>
        </div>
        <button type="submit">Create account</button>
      </form>
    </div>
  );
}