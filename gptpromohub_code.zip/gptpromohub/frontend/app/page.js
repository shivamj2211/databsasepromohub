import Link from 'next/link';

export default function Home() {
  return (
    <div style={{ textAlign: 'center' }}>
      <h1>Welcome to Promohub</h1>
      <p>Connect brands with influencers seamlessly.</p>
      <div style={{ marginTop: '2rem' }}>
        <Link href="/signup"><button>Sign Up</button></Link>
        <span style={{ margin: '0 1rem' }}></span>
        <Link href="/signin"><button>Sign In</button></Link>
      </div>
    </div>
  );
}