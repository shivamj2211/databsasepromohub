'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function InfluencerSummaryPage() {
  const router = useRouter();
  const [headline, setHeadline] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    const userId = sessionStorage.getItem('userId');
    if (!userId) {
      setError('User not found. Please sign up.');
      return;
    }
    try {
      const res = await fetch('/api/influencer/summary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: Number(userId), headline })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save summary');
      router.push('/influencer/description');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div>
      <h2>Influencer Onboarding: Profile Summary</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
        <textarea
          placeholder="Write a concise headline that describes you (e.g. Fashion & Lifestyle Creator)"
          value={headline}
          onChange={(e) => setHeadline(e.target.value)}
          required
        />
        <button type="submit">Continue</button>
      </form>
    </div>
  );
}