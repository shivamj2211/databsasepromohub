'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function InfluencerContentPage() {
  const router = useRouter();
  const [contentTypesInput, setContentTypesInput] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    const userId = sessionStorage.getItem('userId');
    if (!userId) {
      setError('User not found. Please sign up.');
      return;
    }
    const contentTypes = contentTypesInput
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);
    try {
      const res = await fetch('/api/influencer/content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: Number(userId), contentTypes })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save content');
      router.push('/influencer/social');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div>
      <h2>Influencer Onboarding: Content Types</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
        <textarea
          placeholder="Enter your content types separated by commas (e.g. Fashion, Lifestyle, Travel)"
          value={contentTypesInput}
          onChange={(e) => setContentTypesInput(e.target.value)}
        />
        <button type="submit">Continue</button>
      </form>
    </div>
  );
}