'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function InfluencerLocationPage() {
  const router = useRouter();
  const [form, setForm] = useState({
    pincode: '',
    city: '',
    state: '',
    locality: '',
    fullAddress: ''
  });
  const [error, setError] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    const userId = sessionStorage.getItem('userId');
    if (!userId) {
      setError('User not found. Please sign up.');
      return;
    }
    try {
      const res = await fetch('/api/influencer/location', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: Number(userId), ...form })
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to save location');
      }
      router.push('/influencer/profile');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div>
      <h2>Influencer Onboarding: Location</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
        <input name="pincode" placeholder="Pincode" value={form.pincode} onChange={handleChange} required />
        <input name="city" placeholder="City" value={form.city} onChange={handleChange} required />
        <input name="state" placeholder="State" value={form.state} onChange={handleChange} required />
        <input name="locality" placeholder="Locality" value={form.locality} onChange={handleChange} />
        <textarea name="fullAddress" placeholder="Full address" value={form.fullAddress} onChange={handleChange} />
        <button type="submit">Continue</button>
      </form>
    </div>
  );
}