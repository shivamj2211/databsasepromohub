'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';

export default function InfluencerListingsPage() {
  const [influencers, setInfluencers] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    async function fetchInfluencers() {
      try {
        const res = await fetch('/api/influencer');
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Failed to fetch influencers');
        setInfluencers(data.influencers);
      } catch (err) {
        setError(err.message);
      }
    }
    fetchInfluencers();
  }, []);

  return (
    <div>
      <h2>Discover Influencers</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <ul style={{ listStyle: 'none', padding: 0 }}>
        {influencers.map((inf) => (
          <li key={inf.username} style={{ border: '1px solid #ccc', padding: '1rem', marginBottom: '0.5rem' }}>
            <h3>{inf.full_name} (@{inf.username})</h3>
            <p>{inf.headline}</p>
            <p>{inf.city}</p>
            {inf.main_category && <p><strong>Category:</strong> {inf.main_category}</p>}
            <Link href={`/influencer/profile/${inf.username}`}><button>View Profile</button></Link>
          </li>
        ))}
      </ul>
    </div>
  );
}