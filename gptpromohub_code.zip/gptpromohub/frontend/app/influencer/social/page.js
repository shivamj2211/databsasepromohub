'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function InfluencerSocialPage() {
  const router = useRouter();
  const [form, setForm] = useState({
    instagramHandle: '',
    instagramUrl: '',
    instagramFollowers: '',
    youtubeUrl: '',
    youtubeFollowers: '',
    otherSocialLinks: ''
  });
  const [error, setError] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    const userId = sessionStorage.getItem('userId');
    if (!userId) {
      setError('User not found. Please sign up.');
      return;
    }
    try {
      const body = {
        userId: Number(userId),
        instagramHandle: form.instagramHandle || null,
        instagramUrl: form.instagramUrl || null,
        instagramFollowers: form.instagramFollowers ? Number(form.instagramFollowers) : null,
        youtubeUrl: form.youtubeUrl || null,
        youtubeFollowers: form.youtubeFollowers ? Number(form.youtubeFollowers) : null,
        otherSocialLinks: form.otherSocialLinks || null
      };
      const res = await fetch('/api/influencer/social', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save social info');
      router.push('/influencer/summary');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div>
      <h2>Influencer Onboarding: Social Media</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
        <input name="instagramHandle" placeholder="Instagram handle" value={form.instagramHandle} onChange={handleChange} />
        <input name="instagramUrl" placeholder="Instagram URL" value={form.instagramUrl} onChange={handleChange} />
        <input name="instagramFollowers" type="number" placeholder="Instagram followers" value={form.instagramFollowers} onChange={handleChange} />
        <input name="youtubeUrl" placeholder="YouTube URL" value={form.youtubeUrl} onChange={handleChange} />
        <input name="youtubeFollowers" type="number" placeholder="YouTube subscribers" value={form.youtubeFollowers} onChange={handleChange} />
        <textarea name="otherSocialLinks" placeholder="Other social links" value={form.otherSocialLinks} onChange={handleChange} />
        <button type="submit">Continue</button>
      </form>
    </div>
  );
}