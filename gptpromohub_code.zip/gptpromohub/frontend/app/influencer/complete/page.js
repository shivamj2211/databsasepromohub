'use client';

import Link from 'next/link';

export default function InfluencerCompletePage() {
  return (
    <div style={{ textAlign: 'center' }}>
      <h2>Onboarding Complete!</h2>
      <p>Your influencer profile has been created. Brands can now discover and collaborate with you.</p>
      <Link href="/influencer/listings">
        <button>Browse other influencers</button>
      </Link>
    </div>
  );
}