'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function InfluencerDescriptionPage() {
  const router = useRouter();
  const [bio, setBio] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    const userId = sessionStorage.getItem('userId');
    if (!userId) {
      setError('User not found. Please sign up.');
      return;
    }
    try {
      const res = await fetch('/api/influencer/description', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: Number(userId), bio })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save description');
      router.push('/influencer/complete');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div>
      <h2>Influencer Onboarding: Detailed Description</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
        <textarea
          placeholder="Describe yourself, your content and what brands can expect when working with you"
          value={bio}
          onChange={(e) => setBio(e.target.value)}
          required
        />
        <button type="submit">Finish Onboarding</button>
      </form>
    </div>
  );
}