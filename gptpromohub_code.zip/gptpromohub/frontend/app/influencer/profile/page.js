'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function InfluencerProfilePage() {
  const router = useRouter();
  const [form, setForm] = useState({
    gender: '',
    dateOfBirth: '',
    languages: '',
    mainCategory: '',
    subCategory: ''
  });
  const [error, setError] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    const userId = sessionStorage.getItem('userId');
    if (!userId) {
      setError('User not found. Please sign up.');
      return;
    }
    try {
      const body = {
        userId: Number(userId),
        gender: form.gender,
        dateOfBirth: form.dateOfBirth,
        languages: form.languages.split(',').map((s) => s.trim()).filter(Boolean),
        mainCategory: form.mainCategory,
        subCategory: form.subCategory
      };
      const res = await fetch('/api/influencer/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to save profile');
      }
      router.push('/influencer/content');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div>
      <h2>Influencer Onboarding: Personal Details</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
        <input name="gender" placeholder="Gender" value={form.gender} onChange={handleChange} />
        <input name="dateOfBirth" type="date" placeholder="Date of birth" value={form.dateOfBirth} onChange={handleChange} />
        <input name="languages" placeholder="Languages (comma separated)" value={form.languages} onChange={handleChange} />
        <input name="mainCategory" placeholder="Main category (e.g. Fashion)" value={form.mainCategory} onChange={handleChange} />
        <input name="subCategory" placeholder="Sub category" value={form.subCategory} onChange={handleChange} />
        <button type="submit">Continue</button>
      </form>
    </div>
  );
}