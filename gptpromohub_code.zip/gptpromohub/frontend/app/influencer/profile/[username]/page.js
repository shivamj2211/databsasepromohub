'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';

export default function InfluencerProfileView() {
  const params = useParams();
  const username = params.username;
  const [profile, setProfile] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    async function fetchProfile() {
      try {
        const res = await fetch(`/api/influencer/${username}`);
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Failed to fetch profile');
        setProfile(data.profile);
      } catch (err) {
        setError(err.message);
      }
    }
    if (username) fetchProfile();
  }, [username]);

  if (error) return <p style={{ color: 'red' }}>{error}</p>;
  if (!profile) return <p>Loading...</p>;

  return (
    <div>
      <h2>{profile.full_name} (@{profile.username})</h2>
      {profile.headline && <p><strong>Headline:</strong> {profile.headline}</p>}
      {profile.bio && <p><strong>Bio:</strong> {profile.bio}</p>}
      {profile.city && <p><strong>Location:</strong> {profile.city}, {profile.state}</p>}
      {profile.languages && <p><strong>Languages:</strong> {profile.languages}</p>}
      {profile.main_category && <p><strong>Main Category:</strong> {profile.main_category}</p>}
      {profile.sub_category && <p><strong>Sub Category:</strong> {profile.sub_category}</p>}
      {profile.instagram_handle && (
        <p>
          <strong>Instagram:</strong> <a href={profile.instagram_url} target="_blank" rel="noreferrer">{profile.instagram_handle}</a> ({profile.instagram_followers} followers)
        </p>
      )}
      {profile.youtube_url && (
        <p>
          <strong>YouTube:</strong> <a href={profile.youtube_url} target="_blank" rel="noreferrer">Channel</a> ({profile.youtube_followers} subscribers)
        </p>
      )}
      {profile.other_social_links && <p><strong>Other Links:</strong> {profile.other_social_links}</p>}
    </div>
  );
}