'use client';

import Link from 'next/link';

export default function BrandCompletePage() {
  return (
    <div style={{ textAlign: 'center' }}>
      <h2>Brand Onboarding Complete!</h2>
      <p>Your brand profile has been created. Start browsing influencers to collaborate.</p>
      <Link href="/influencer/listings"><button>Browse Influencers</button></Link>
    </div>
  );
}