'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function BrandHereToDoPage() {
  const router = useRouter();
  const [hereToDo, setHereToDo] = useState('one-time campaign');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    const userId = sessionStorage.getItem('userId');
    if (!userId) {
      setError('User not found. Please sign up.');
      return;
    }
    try {
      const res = await fetch('/api/brand/heretodo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: Number(userId), hereToDo })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save');
      router.push('/brand/budget');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div>
      <h2>Brand Onboarding: What are you here to do?</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <form onSubmit={handleSubmit}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
          <label>
            <input
              type="radio"
              name="hereToDo"
              value="one-time campaign"
              checked={hereToDo === 'one-time campaign'}
              onChange={(e) => setHereToDo(e.target.value)}
            />
            One-time campaign
          </label>
          <label>
            <input
              type="radio"
              name="hereToDo"
              value="ongoing partnerships"
              checked={hereToDo === 'ongoing partnerships'}
              onChange={(e) => setHereToDo(e.target.value)}
            />
            Ongoing partnerships
          </label>
          <label>
            <input
              type="radio"
              name="hereToDo"
              value="just exploring"
              checked={hereToDo === 'just exploring'}
              onChange={(e) => setHereToDo(e.target.value)}
            />
            Just exploring
          </label>
        </div>
        <button type="submit" style={{ marginTop: '1rem' }}>Continue</button>
      </form>
    </div>
  );
}