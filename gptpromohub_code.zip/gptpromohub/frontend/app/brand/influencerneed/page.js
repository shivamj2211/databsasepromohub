'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function BrandInfluencerNeedPage() {
  const router = useRouter();
  const [influencerType, setInfluencerType] = useState('nano');
  const [preferredPlatforms, setPreferredPlatforms] = useState('');
  const [preferredCategories, setPreferredCategories] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    const userId = sessionStorage.getItem('userId');
    if (!userId) {
      setError('User not found. Please sign up.');
      return;
    }
    try {
      const body = {
        userId: Number(userId),
        influencerType,
        preferredPlatforms: preferredPlatforms
          .split(',')
          .map((s) => s.trim())
          .filter(Boolean),
        preferredCategories: preferredCategories
          .split(',')
          .map((s) => s.trim())
          .filter(Boolean)
      };
      const res = await fetch('/api/brand/influencer-need', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save');
      router.push('/brand/complete');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div>
      <h2>Brand Onboarding: Influencer Requirements</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
        <label>
          Influencer Type
          <select value={influencerType} onChange={(e) => setInfluencerType(e.target.value)}>
            <option value="nano">Nano</option>
            <option value="micro">Micro</option>
            <option value="macro">Macro</option>
          </select>
        </label>
        <textarea
          placeholder="Preferred platforms (comma separated, e.g. Instagram, YouTube)"
          value={preferredPlatforms}
          onChange={(e) => setPreferredPlatforms(e.target.value)}
        />
        <textarea
          placeholder="Preferred categories (comma separated, e.g. Fashion, Technology)"
          value={preferredCategories}
          onChange={(e) => setPreferredCategories(e.target.value)}
        />
        <button type="submit">Finish Onboarding</button>
      </form>
    </div>
  );
}