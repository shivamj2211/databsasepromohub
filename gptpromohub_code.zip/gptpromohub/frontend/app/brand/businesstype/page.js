'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function BrandBusinessTypePage() {
  const router = useRouter();
  const [businessType, setBusinessType] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    const userId = sessionStorage.getItem('userId');
    if (!userId) {
      setError('User not found. Please sign up.');
      return;
    }
    try {
      const res = await fetch('/api/brand/business', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: Number(userId), businessType })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save');
      router.push('/brand/influencerneed');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div>
      <h2>Brand Onboarding: Business Type</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
        <input
          placeholder="Type of business (e.g. Agency, E-commerce, App)"
          value={businessType}
          onChange={(e) => setBusinessType(e.target.value)}
          required
        />
        <button type="submit">Continue</button>
      </form>
    </div>
  );
}