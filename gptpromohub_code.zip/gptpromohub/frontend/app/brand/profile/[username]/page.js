'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';

export default function BrandProfileView() {
  const params = useParams();
  const username = params.username;
  const [profile, setProfile] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    async function fetchProfile() {
      try {
        const res = await fetch(`/api/brand/${username}`);
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Failed to fetch profile');
        setProfile(data.profile);
      } catch (err) {
        setError(err.message);
      }
    }
    if (username) fetchProfile();
  }, [username]);

  if (error) return <p style={{ color: 'red' }}>{error}</p>;
  if (!profile) return <p>Loading...</p>;

  return (
    <div>
      <h2>{profile.full_name} (@{profile.username})</h2>
      {profile.here_to_do && <p><strong>Goal:</strong> {profile.here_to_do}</p>}
      {profile.business_type && <p><strong>Business Type:</strong> {profile.business_type}</p>}
      {profile.influencer_type && <p><strong>Influencer Type:</strong> {profile.influencer_type}</p>}
      {profile.preferred_platforms && <p><strong>Preferred Platforms:</strong> {profile.preferred_platforms}</p>}
      {profile.preferred_categories && <p><strong>Preferred Categories:</strong> {profile.preferred_categories}</p>}
      {profile.budget_level && <p><strong>Budget:</strong> {profile.budget_level}</p>}
    </div>
  );
}