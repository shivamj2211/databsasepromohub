'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function BrandBudgetPage() {
  const router = useRouter();
  const [budgetLevel, setBudgetLevel] = useState('');
  const [budgetMin, setBudgetMin] = useState('');
  const [budgetMax, setBudgetMax] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    const userId = sessionStorage.getItem('userId');
    if (!userId) {
      setError('User not found. Please sign up.');
      return;
    }
    try {
      const body = {
        userId: Number(userId),
        budgetLevel: budgetLevel || null,
        budgetMin: budgetMin ? Number(budgetMin) : null,
        budgetMax: budgetMax ? Number(budgetMax) : null
      };
      const res = await fetch('/api/brand/budget', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to save');
      router.push('/brand/businesstype');
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div>
      <h2>Brand Onboarding: Budget</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
        <input
          placeholder="Budget level label (e.g. Under 1k, 1k-5k)"
          value={budgetLevel}
          onChange={(e) => setBudgetLevel(e.target.value)}
        />
        <input
          type="number"
          placeholder="Minimum budget (INR)"
          value={budgetMin}
          onChange={(e) => setBudgetMin(e.target.value)}
        />
        <input
          type="number"
          placeholder="Maximum budget (INR)"
          value={budgetMax}
          onChange={(e) => setBudgetMax(e.target.value)}
        />
        <button type="submit">Continue</button>
      </form>
    </div>
  );
}