export const metadata = {
  title: 'Promohub',
  description: 'Promohub: connect brands with influencers'
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body style={{ margin: 0, fontFamily: 'sans-serif' }}>
        <main style={{ maxWidth: 720, margin: '0 auto', padding: '1rem' }}>
          {children}
        </main>
      </body>
    </html>
  );
}