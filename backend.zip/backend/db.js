const { Pool } = require('pg');

/**
 * Configure a PostgreSQL connection pool.
 *
 * The database credentials can be supplied via environment variables or a
 * `DATABASE_URL`. For local development create a `.env` with PGHOST, PGUSER,
 * PGPASSWORD, PGDATABASE, PGPORT or set `DATABASE_URL` (e.g.
 * `postgres://user:pass@localhost:5432/promohub`).
 */
require('dotenv').config();

let pool;
if (process.env.DATABASE_URL) {
  pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    // If your Postgres instance requires TLS in your environment, uncomment:
    // ssl: { rejectUnauthorized: false }
  });
} else {
  const config = {
    host: process.env.PGHOST || 'localhost',
    port: process.env.PGPORT ? parseInt(process.env.PGPORT, 10) : 5432,
    user: process.env.PGUSER || 'postgres',
    // Do not provide a hardcoded password. Require the environment to supply it.
    password: process.env.PGPASSWORD || undefined,
    database: process.env.PGDATABASE || 'promohub'
  };

  if (!config.user || !config.password) {
    console.warn('\nPostgres credentials appear incomplete.\n' +
      'Set PGUSER and PGPASSWORD in your environment or provide DATABASE_URL.\n' +
      'Example (PowerShell): $env:PGUSER="postgres"; $env:PGPASSWORD="yourpassword"\n');
  }

  pool = new Pool(config);
}

// Give a clearer runtime message if the pool emits an error (e.g., auth failure)
pool.on('error', (err) => {
  console.error('Unexpected Postgres error on idle client', err);
  if (err && err.code === '28P01') {
    console.error('Authentication failed (28P01): check PGUSER/PGPASSWORD or DATABASE_URL.');
  }
});

module.exports = {
  /**
   * Execute an SQL query using the connection pool. Logs errors and rethrows
   * them so callers can handle them appropriately.
   *
   * @param {string} text The parameterised SQL query
   * @param {Array} [params] Optional list of parameters
   * @returns {Promise<object>} The result object from pg
   */
  query: async (text, params) => {
    const client = await pool.connect();
    try {
      const res = await client.query(text, params);
      return res;
    } catch (err) {
      console.error('Database query error:', err);
      throw err;
    } finally {
      client.release();
    }
  }
};