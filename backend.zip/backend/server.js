const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const db = require('./db');

// Import route modules
const authRoutes = require('./routes/auth');
const influencerRoutes = require('./routes/influencer');
const brandRoutes = require('./routes/brand');

const app = express();

// Enable Cross-Origin requests to allow the frontend running on a different
// port (e.g. Next.js dev server) to call this API. In production you can
// restrict the origins as appropriate.
app.use(cors());

// Parse JSON request bodies
app.use(bodyParser.json());

// Simple health check endpoint
app.get('/api/db-test', async (req, res) => {
  try {
    const result = await db.query('SELECT NOW() as now');
    res.json({ ok: true, now: result.rows[0].now });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

// Mount route modules. Auth routes are mounted under `/api/auth` so frontend
// can call `/api/auth/signup`, `/api/auth/set-username`, `/api/auth/login`.
app.use('/api/auth', authRoutes);
app.use('/api/influencer', influencerRoutes);
app.use('/api/brand', brandRoutes);

// Start the server
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Promohub backend listening on port ${PORT}`);
});