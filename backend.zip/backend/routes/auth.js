const express = require('express');
const bcrypt = require('bcrypt');

const db = require('../db');

const router = express.Router();

/**
 * User registration endpoint. Creates a new record in the users table and
 * automatically inserts a corresponding record in the influencer_profiles or
 * brand_profiles table based on the provided `userType`. Passwords are
 * hashed using bcrypt before storage.
 *
 * Expected JSON body:
 * {
 *   "fullName": "string",
 *   "email": "string",
 *   "username": "string",
 *   "password": "string",
 *   "phone": "string",
 *   "countryCode": "string",
 *   "userType": "influencer" | "brand"
 * }
 */
// Step 1: Signup creates the user without a username and without creating a
// profile row. Username is claimed later via `/set-username`.
router.post('/signup', async (req, res) => {
  const {
    fullName,
    email,
    password,
    phone,
    countryCode,
    userType
  } = req.body;

  if (!fullName || !email || !password || !userType || !phone) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  if (!['influencer', 'brand'].includes(userType)) {
    return res.status(400).json({ error: 'Invalid user type' });
  }

  try {
    const passwordHash = await bcrypt.hash(password, 10);

    const result = await db.query(`
      INSERT INTO users (full_name, email, phone, country_code, user_type, password_hash, created_at, updated_at)
      VALUES ($1, $2, $3, $4, $5, $6, NOW(), NOW())
      RETURNING id;
    `, [fullName, email, phone, countryCode, userType, passwordHash]);

    res.status(201).json({ ok: true, userId: result.rows[0].id });
  } catch (err) {
    console.error('Signup error:', err);
    if (err.code === '23505') {
      let detail = 'Duplicate field';
      if (err.detail && err.detail.includes('email')) detail = 'Email already exists';
      if (err.detail && err.detail.includes('phone')) detail = 'Phone number already exists';
      return res.status(409).json({ error: detail });
    }
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Step 2: Claim a username. This endpoint updates the user record only if
// the username is currently NULL and the requested username is unique.
router.post('/set-username', async (req, res) => {
  const { userId, username } = req.body;

  if (!userId || !username) {
    return res.status(400).json({ error: 'Missing userId or username' });
  }

  try {
    // Attempt to set the username only if it's not already set.
    const update = await db.query(`
      UPDATE users SET username = $1, updated_at = NOW()
      WHERE id = $2 AND username IS NULL
      RETURNING id, user_type;
    `, [username, userId]);

    if (update.rowCount === 0) {
      return res.status(409).json({ error: 'Username already set or user not found' });
    }

    const { user_type } = update.rows[0];

    // Create the corresponding profile now that username is claimed.
    if (user_type === 'influencer') {
      await db.query(
        `INSERT INTO influencer_profiles (user_id, created_at, updated_at) VALUES ($1, NOW(), NOW())`,
        [userId]
      );
    } else if (user_type === 'brand') {
      await db.query(
        `INSERT INTO brand_profiles (user_id, created_at, updated_at) VALUES ($1, NOW(), NOW())`,
        [userId]
      );
    }

    res.json({ ok: true });
  } catch (err) {
    console.error('Username claim error:', err);
    if (err.code === '23505' && err.detail && err.detail.includes('username')) {
      return res.status(409).json({ error: 'Username already taken' });
    }
    res.status(500).json({ error: 'Internal server error' });
  }
});

/**
 * User login endpoint. Validates credentials against the stored password hash.
 * Returns the user id and user type on success. This simplistic implementation
 * does not return a JWT; in a real application you would return a token or
 * establish a session.
 *
 * Expected JSON body:
 * {
 *   "emailOrUsername": "string",
 *   "password": "string"
 * }
 */
router.post('/login', async (req, res) => {
  const { emailOrUsername, password } = req.body;
  if (!emailOrUsername || !password) {
    return res.status(400).json({ error: 'Missing credentials' });
  }
  try {
    // Attempt to find the user by email or username
    const findUserQuery = `
      SELECT id, password_hash, user_type
      FROM users
      WHERE email = $1 OR username = $1
      LIMIT 1;
    `;
    const result = await db.query(findUserQuery, [emailOrUsername]);
    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    const user = result.rows[0];
    const passwordMatch = await bcrypt.compare(password, user.password_hash);
    if (!passwordMatch) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    res.json({ ok: true, userId: user.id, userType: user.user_type });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Check username availability (case-sensitive check by DB)
// GET /username-available?username=ArjunLive
router.get('/username-available', async (req, res) => {
  const username = req.query.username;
  if (!username) {
    return res.status(400).json({ error: 'Missing username query parameter' });
  }
  try {
    const q = `SELECT 1 FROM users WHERE username = $1 LIMIT 1`;
    const result = await db.query(q, [username]);
    const available = result.rows.length === 0;
    res.json({ available });
  } catch (err) {
    console.error('Username availability check error:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;